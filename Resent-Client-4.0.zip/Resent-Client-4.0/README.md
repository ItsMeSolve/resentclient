Resent Client 3.8 on Netlify

https://resentx.netlify.app
